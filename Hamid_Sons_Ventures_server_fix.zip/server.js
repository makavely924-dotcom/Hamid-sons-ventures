const express = require("express");
const path = require("path");
const crypto = require("crypto");
const fs = require("fs");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "CHANGE_ME_NOW";
const WA = (process.env.WA_NUMBER || "2348166545358").replace(/\D/g, "");
const dbFile = process.env.DB_FILE || path.join(__dirname, "data.sqlite");
const dbDir = path.dirname(dbFile);
if (dbDir && dbDir !== ".") fs.mkdirSync(dbDir, { recursive: true });
const db = new Database(dbFile);

db.exec(`
CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT NOT NULL,price INTEGER NOT NULL,description TEXT DEFAULT '',icon TEXT DEFAULT '📦',active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY,customer_name TEXT NOT NULL,phone TEXT NOT NULL,address TEXT NOT NULL,delivery TEXT NOT NULL,total INTEGER NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS order_items (id INTEGER PRIMARY KEY AUTOINCREMENT,order_id TEXT NOT NULL,product_id INTEGER NOT NULL,name TEXT NOT NULL,qty INTEGER NOT NULL,price INTEGER NOT NULL);
`);

if (db.prepare("SELECT COUNT(*) AS c FROM products").get().c === 0) {
  const insert = db.prepare("INSERT INTO products(name,category,price,description,icon) VALUES(?,?,?,?,?)");
  [
    ["Dangote 3X Cement (50kg)","Cement",11500,"Quality cement for general construction.","🧱"],
    ["Block Master Cement (50kg)","Cement",11500,"Reliable cement for block making.","🧱"],
    ["60×60 Ceramic Tiles","Tiles",6850,"Modern ceramic tiles for floors and walls.","◻️"],
    ["12mm Iron Rod","Iron Rods",8300,"Strong reinforcement rod for construction.","〽️"]
  ].forEach(x => insert.run(...x));
}

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const sessions = new Set();
const money = n => "₦" + Number(n || 0).toLocaleString("en-NG");

function auth(req,res,next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : "";
  if (!token || !sessions.has(token)) return res.status(401).json({error:"Unauthorized"});
  next();
}

app.get("/health", (req,res) => res.json({ok:true,service:"Hamid & Son's Ventures"}));

app.get("/api/products", (req,res) => {
  const search = String(req.query.q || "").toLowerCase().trim();
  const category = String(req.query.category || "All");
  let products = db.prepare("SELECT * FROM products WHERE active=1 ORDER BY id DESC").all();
  if (category !== "All") products = products.filter(p => p.category === category);
  if (search) products = products.filter(p => `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(search));
  res.json(products);
});

app.get("/api/categories", (req,res) => {
  res.json(db.prepare("SELECT DISTINCT category FROM products WHERE active=1 ORDER BY category").all().map(x => x.category));
});

app.post("/api/orders", (req,res) => {
  try {
    const {customerName,phone,address,delivery="Standard",items} = req.body || {};
    if (!customerName || !phone || !address || !Array.isArray(items) || !items.length)
      return res.status(400).json({error:"Complete customer details and cart are required"});

    let subtotal = 0;
    const rows = [];
    for (const item of items) {
      const productId = Number(item.productId);
      const qty = Math.max(1, Math.floor(Number(item.qty) || 0));
      const product = db.prepare("SELECT * FROM products WHERE id=? AND active=1").get(productId);
      if (!product) return res.status(400).json({error:"Invalid product or quantity"});
      subtotal += product.price * qty;
      rows.push({product,qty});
    }

    const deliveryFee = delivery === "Express" ? 4000 : 2000;
    const total = subtotal + deliveryFee;
    const orderId = "HSV-" + crypto.randomBytes(3).toString("hex").toUpperCase();
    const now = new Date().toISOString();

    const save = db.transaction(() => {
      db.prepare(`INSERT INTO orders (id,customer_name,phone,address,delivery,total,status,created_at) VALUES (?,?,?,?,?,?,?,?)`)
        .run(orderId,String(customerName),String(phone),String(address),String(delivery),total,"New",now);
      const ins = db.prepare(`INSERT INTO order_items (order_id,product_id,name,qty,price) VALUES (?,?,?,?,?)`);
      rows.forEach(r => ins.run(orderId,r.product.id,r.product.name,r.qty,r.product.price));
    });
    save();

    const itemText = rows.map(r => `${r.qty} × ${r.product.name} — ${money(r.product.price*r.qty)}`).join("\n");
    const message = ["Hello Hamid & Son's Ventures,","",`Order: ${orderId}`,`Customer: ${customerName}`,`Phone: ${phone}`,`Address: ${address}`,`Delivery: ${delivery}`,"",itemText,`Delivery: ${money(deliveryFee)}`,`Total: ${money(total)}`].join("\n");
    res.json({id:orderId,subtotal,deliveryFee,total,whatsapp:`https://wa.me/${WA}?text=${encodeURIComponent(message)}`});
  } catch (err) {
    console.error("Order error:",err);
    res.status(500).json({error:"Could not create order"});
  }
});

app.post("/api/admin/login", (req,res) => {
  const {username,password} = req.body || {};
  if (username === ADMIN_USER && password === ADMIN_PASSWORD) {
    const token = crypto.randomBytes(24).toString("hex");
    sessions.add(token);
    return res.json({token});
  }
  res.status(401).json({error:"Invalid login"});
});

app.post("/api/admin/logout",auth,(req,res) => {
  const h = req.headers.authorization || "";
  sessions.delete(h.startsWith("Bearer ") ? h.slice(7) : "");
  res.json({ok:true});
});

app.get("/api/admin/products",auth,(req,res) => res.json(db.prepare("SELECT * FROM products ORDER BY id DESC").all()));

app.patch("/api/admin/products/:id",auth,(req,res) => {
  const id = Number(req.params.id);
  const old = db.prepare("SELECT * FROM products WHERE id=?").get(id);
  if (!old) return res.status(404).json({error:"Product not found"});
  const p = {
    name:req.body.name ?? old.name,
    category:req.body.category ?? old.category,
    price:Number(req.body.price ?? old.price),
    description:req.body.description ?? old.description,
    icon:req.body.icon ?? old.icon,
    active:req.body.active === undefined ? old.active : (req.body.active ? 1 : 0)
  };
  if (!p.name || !p.category || !Number.isFinite(p.price) || p.price < 0)
    return res.status(400).json({error:"Invalid product details"});
  db.prepare("UPDATE products SET name=?,category=?,price=?,description=?,icon=?,active=? WHERE id=?")
    .run(p.name,p.category,p.price,p.description,p.icon,p.active,id);
  res.json(db.prepare("SELECT * FROM products WHERE id=?").get(id));
});

app.post("/api/admin/products",auth,(req,res) => {
  const {name,category,price,description="",icon="📦"} = req.body || {};
  const numericPrice = Number(price);
  if (!name || !category || !Number.isFinite(numericPrice) || numericPrice <= 0)
    return res.status(400).json({error:"Name, category and valid price are required"});
  const r = db.prepare("INSERT INTO products(name,category,price,description,icon) VALUES(?,?,?,?,?)")
    .run(String(name),String(category),numericPrice,String(description),String(icon));
  res.json(db.prepare("SELECT * FROM products WHERE id=?").get(r.lastInsertRowid));
});

app.delete("/api/admin/products/:id",auth,(req,res) => {
  db.prepare("UPDATE products SET active=0 WHERE id=?").run(Number(req.params.id));
  res.json({ok:true});
});

app.get("/api/admin/orders",auth,(req,res) => res.json(db.prepare("SELECT * FROM orders ORDER BY created_at DESC").all()));

app.patch("/api/admin/orders/:id",auth,(req,res) => {
  const allowed = ["New","Confirmed","Preparing","Out for delivery","Delivered","Cancelled"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({error:"Invalid status"});
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,String(req.params.id));
  res.json({ok:true});
});

// Frontend fallback without the Express route-pattern issue that caused crashes.
app.use((req,res) => {
  if (req.method === "GET" && !req.path.startsWith("/api/"))
    return res.sendFile(path.join(__dirname,"public","index.html"));
  res.status(404).json({error:"Not found"});
});

app.listen(PORT,"0.0.0.0",() => console.log(`Hamid & Son's Ventures running on port ${PORT}`));
